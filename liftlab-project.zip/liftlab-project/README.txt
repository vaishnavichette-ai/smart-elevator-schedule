﻿# LiftLab — Smart Elevator Scheduler

## Files

- `app.py` — Flask web server, API validation, greedy scheduler, and priority-queue scheduler.
- `templates/index.html` — visual interface. It sends scheduling inputs to the Python backend and displays both schedules.

Keep `app.py` next to the `templates` folder when extracting the package.

## Start on Windows

1. Install Python 3 if it is not already installed, and make sure the `python` command works in PowerShell.
2. Open PowerShell in the folder containing `app.py`.
3. Run these commands:

```powershell
python -m pip install flask
python app.py
```

4. Leave that PowerShell window open and visit `http://127.0.0.1:5000` in your browser. Do not open `templates/index.html` directly; the page needs the running Flask server for its `/api/schedule` endpoint.

The greedy scheduler picks the nearest available call. The priority queue orders calls by priority (5 first), then oldest release time, then nearest floor, then call ID. Both schedules show pickup order, arrival and wait times, average and maximum wait, and travel time.
